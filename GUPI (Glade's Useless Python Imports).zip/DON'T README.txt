hi thanks for downloading

feel free to read the epic gamer code B)