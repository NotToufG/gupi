def detune(freq,cents):
    return freq*2**(cents/1200)