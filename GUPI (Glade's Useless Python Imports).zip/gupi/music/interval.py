def interval(n1,n2):
    return abs(n2-n1)