def bpm_to_ms(bpm):
    return 60000/bpm