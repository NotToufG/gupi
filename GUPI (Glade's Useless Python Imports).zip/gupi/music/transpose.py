def transpose(notes,interval):
    return [n+interval for n in notes]