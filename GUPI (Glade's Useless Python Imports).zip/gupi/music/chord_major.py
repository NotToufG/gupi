def chord_major(root):
    return [root,root+4,root+7]