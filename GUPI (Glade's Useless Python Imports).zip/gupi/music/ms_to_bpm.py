def ms_to_bpm(ms):
    return 60000/ms