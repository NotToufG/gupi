def chord_minor(root):
    return [root,root+3,root+7]