def invert(chord):
    return chord[1:]+[chord[0]+12]