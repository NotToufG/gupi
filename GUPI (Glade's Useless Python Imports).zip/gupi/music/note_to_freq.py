def note_to_freq(note):
    return 440.0*2**((note-69)/12)