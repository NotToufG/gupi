def harmonics(freq,n):
    return [freq*(i+1) for i in range(n)]