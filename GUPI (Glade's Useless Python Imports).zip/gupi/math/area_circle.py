from math import pi
def area_circle(r):
    return pi*r*r