def area_triangle(b,h):
    return 0.5*b*h