def palindrome(s):
    return s==s[::-1]