def line_count(s):
    return len(s.splitlines())