def capitalize_words(s):
    return ' '.join(w.capitalize() for w in s.split())