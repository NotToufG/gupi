def char_count(s):
    return len(s)