def to_lower(s):
    return s.lower()