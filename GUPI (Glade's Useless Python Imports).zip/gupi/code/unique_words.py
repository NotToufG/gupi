def unique_words(s):
    return set(s.split())