def strip_whitespace(s):
    return s.strip()