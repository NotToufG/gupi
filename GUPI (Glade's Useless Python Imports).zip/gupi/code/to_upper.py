def to_upper(s):
    return s.upper()