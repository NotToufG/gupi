def word_count(s):
    return len(s.split())