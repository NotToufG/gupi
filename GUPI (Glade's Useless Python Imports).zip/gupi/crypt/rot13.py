import codecs
def rot13(s):
    return codecs.encode(s,'rot_13')