def xml_escape(s):
    return s.replace('&','&amp;').replace('<','&lt;').replace('>','&gt;')