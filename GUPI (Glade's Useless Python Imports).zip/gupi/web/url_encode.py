import urllib.parse
def url_encode(s):
    return urllib.parse.quote(s)