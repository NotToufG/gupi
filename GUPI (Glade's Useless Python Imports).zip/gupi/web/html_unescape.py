import html
def html_unescape(s):
    return html.unescape(s)