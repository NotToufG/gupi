import urllib.parse
def url_decode(s):
    return urllib.parse.unquote(s)