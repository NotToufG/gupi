from urllib.parse import urlencode
def dict_to_query(d):
    return urlencode(d)