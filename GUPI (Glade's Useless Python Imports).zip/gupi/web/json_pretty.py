import json
def json_pretty(obj):
    return json.dumps(obj,indent=2)