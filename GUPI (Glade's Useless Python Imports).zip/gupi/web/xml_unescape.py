def xml_unescape(s):
    return s.replace('&lt;','<').replace('&gt;','>').replace('&amp;','&')