import html
def html_escape(s):
    return html.escape(s)